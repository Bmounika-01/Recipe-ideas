import { RecipeSearch } from "@/components/RecipeSearch";
import heroImage from "@/assets/recipe-hero.jpg";
import { ChefHat } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-hero opacity-90" />
        
        <div className="relative container mx-auto px-4 py-20 text-center">
          <div className="flex justify-center mb-6">
            <ChefHat className="h-16 w-16 text-primary-foreground" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-primary-foreground">
            Recipe Finder
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-primary-foreground/90 max-w-2xl mx-auto">
            Discover delicious recipes based on ingredients you have at home. 
            Perfect for busy professionals who want to cook something amazing!
          </p>
          <div className="inline-flex items-center gap-2 bg-primary-foreground/20 backdrop-blur-sm rounded-full px-6 py-3 text-primary-foreground">
            <span className="font-medium">Built for Taylor and busy food lovers everywhere</span>
          </div>
        </div>
      </section>

      {/* Search Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
              What's in your kitchen?
            </h2>
            <p className="text-lg text-muted-foreground max-w-xl mx-auto">
              Enter any ingredient and we'll find amazing recipes you can make right now
            </p>
          </div>
          <RecipeSearch />
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-card border-t">
        <div className="container mx-auto px-4 text-center">
          <div className="flex justify-center items-center gap-2 mb-4">
            <ChefHat className="h-6 w-6 text-primary" />
            <span className="font-semibold text-foreground">Recipe Finder</span>
          </div>
          <p className="text-muted-foreground">
            Powered by TheMealDB API • Built for food enthusiasts
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;