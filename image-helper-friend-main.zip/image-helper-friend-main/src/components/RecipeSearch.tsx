import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Search, Clock, Users, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Recipe {
  idMeal: string;
  strMeal: string;
  strMealThumb: string;
  strInstructions: string;
}

export const RecipeSearch = () => {
  const [ingredient, setIngredient] = useState("");
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const { toast } = useToast();

  const searchRecipes = async () => {
    if (!ingredient.trim()) {
      toast({
        title: "Please enter an ingredient",
        description: "Type an ingredient to find delicious recipes!",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    setHasSearched(true);

    try {
      const response = await fetch(
        `https://www.themealdb.com/api/json/v1/1/filter.php?i=${encodeURIComponent(ingredient)}`
      );
      
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      
      const data = await response.json();
      
      if (data.meals) {
        // Get detailed recipe information for first 6 recipes
        const detailedRecipes = await Promise.all(
          data.meals.slice(0, 6).map(async (meal: any) => {
            const detailResponse = await fetch(
              `https://www.themealdb.com/api/json/v1/1/lookup.php?i=${meal.idMeal}`
            );
            const detailData = await detailResponse.json();
            return detailData.meals[0];
          })
        );
        setRecipes(detailedRecipes);
        toast({
          title: "Recipes found!",
          description: `Found ${detailedRecipes.length} delicious recipes with ${ingredient}`,
        });
      } else {
        setRecipes([]);
        toast({
          title: "No recipes found",
          description: `Try searching with a different ingredient like "chicken", "tomato", or "cheese"`,
        });
      }
    } catch (error) {
      console.error('Error fetching recipes:', error);
      setRecipes([]);
      toast({
        title: "Something went wrong",
        description: "Please check your internet connection and try again",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      searchRecipes();
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto px-4">
      {/* Search Section */}
      <div className="bg-card rounded-xl p-8 shadow-recipe-card mb-8">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
            <Input
              type="text"
              placeholder="Enter an ingredient (e.g., chicken, tomato, cheese)"
              value={ingredient}
              onChange={(e) => setIngredient(e.target.value)}
              onKeyPress={handleKeyPress}
              className="pl-10 h-12 text-lg border-2 focus:border-primary"
            />
          </div>
          <Button
            onClick={searchRecipes}
            disabled={loading}
            className="h-12 px-8 bg-gradient-primary hover:opacity-90 transition-smooth font-semibold"
          >
            {loading ? "Searching..." : "Find Recipes"}
          </Button>
        </div>
      </div>

      {/* Results Section */}
      {hasSearched && (
        <div>
          {recipes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recipes.map((recipe) => (
                <Card key={recipe.idMeal} className="overflow-hidden shadow-recipe-card hover:shadow-lg transition-smooth">
                  <div className="aspect-video overflow-hidden">
                    <img
                      src={recipe.strMealThumb}
                      alt={recipe.strMeal}
                      className="w-full h-full object-cover hover:scale-105 transition-smooth"
                      loading="lazy"
                    />
                  </div>
                  <CardContent className="p-6">
                    <h3 className="font-bold text-xl mb-3 text-foreground line-clamp-2">
                      {recipe.strMeal}
                    </h3>
                    <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
                      {recipe.strInstructions?.substring(0, 120)}...
                    </p>
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        <span>30-45 min</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        <span>2-4 people</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-8 text-center">
              <AlertCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No recipes found</h3>
              <p className="text-muted-foreground">
                Try searching with popular ingredients like "chicken", "beef", "tomato", or "rice"
              </p>
            </Card>
          )}
        </div>
      )}
    </div>
  );
};